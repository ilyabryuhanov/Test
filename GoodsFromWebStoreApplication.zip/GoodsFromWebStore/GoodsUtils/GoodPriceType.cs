﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsFromWebStore.GoodsUtils
{
    public enum GoodsPriceType
    {
        Rub,
        Usd,
        Euro
    }
}
